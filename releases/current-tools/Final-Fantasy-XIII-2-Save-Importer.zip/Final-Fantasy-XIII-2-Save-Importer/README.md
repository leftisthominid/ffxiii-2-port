# Final Fantasy XIII-2 - Triumtemporate Edition - Save Importer

Close the game, then double-click **Import Final Fantasy XIII-2 Save.bat**.
Paste the path to the original Xbox 360 save package, then select the output folder used by
the Windows builder (default: `C:\Final Fantasy XIII-2`). Use the package itself, not an
extracted APP.DAT file. Original Xbox files are only read.

The tool checks that the package belongs to XIII-2, validates its contents, backs up existing
XIII-2 saves and headers, and imports the package for the port's local profile. It opens the
save folder when done. Start the game normally and choose Load Game. An existing save in the
same slot is replaced after backup; retain the backup folder shown by the tool.

Final Fantasy XIII saves are rejected. Structural extraction and header generation have been
verified locally; successful in-game loading is not yet verified for this release. Windows
junction creation and this interactive wrapper still need Windows testing.

Source license: GPL-3.0 (LICENSE). No game saves or other game assets are distributed.
