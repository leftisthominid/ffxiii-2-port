@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Import-XIII2-Save.ps1" %*
set "result=%ERRORLEVEL%"
echo.
pause
exit /b %result%
